from django.urls import path     
from . views import *

urlpatterns = [
    path('', index),
    path("user/login", loginUser),
    path("user/create", createUser),
    path("user/logout", logoutUser),
    path("success", success)
    ]
