from django.apps import AppConfig


class LogregappConfig(AppConfig):
    name = 'LogRegApp'
