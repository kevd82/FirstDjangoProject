
from django.urls import path, include

urlpatterns = [
    path('shows/', include("SemiApp.urls")),
]
